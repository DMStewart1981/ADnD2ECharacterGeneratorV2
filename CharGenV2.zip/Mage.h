#ifndef MAGE_H
#define MAGE_H
#include "Character.h"
#pragma once

class Mage : public Character {

	Mage(int Str_in, int Dex_in, int Con_in, int Int_in, int Wis_in, int Cha_in, std::string CharName_in):
		Character(Str_in, Dex_in, Con_in, Int_in, Wis_in, Cha_in, CharName_in, "Mage") {
		HitDie = 4;

		HP = 4 + HPAdj;
	}

	void SetSaves();

	void StrAdjustment();

	void ConAdjustment();

	void IntAdjustment();

	void WisAdjustment();

	void LevelUp();

};




#endif