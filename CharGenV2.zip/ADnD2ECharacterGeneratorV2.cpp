// ADnD2ECharacterGeneratorV2.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <fstream>
#include "BasicDefs.h"
//#include "Character.h"
//#include "Warrior.h"
//#include "Mage.h"
//#include "Priest.h"
//#include "Rogue.h"

int main()
{

    Attributes Generator;

    std::cout << "Enter Character Name: " << std::endl;

    std::cin >> Generator.CharName;

    do {
        Generator.RollAttributes();
        std::cout << "STR = " << Generator.Str << std::endl;
        std::cout << "DEX = " << Generator.Dex << std::endl;
        std::cout << "CON = " << Generator.Con << std::endl;
        std::cout << "INT = " << Generator.Int << std::endl;
        std::cout << "WIS = " << Generator.Wis << std::endl;
        std::cout << "CHA = " << Generator.Cha << std::endl;
    } while ((Generator.Str < 9) && (Generator.Dex < 9) && (Generator.Int < 9) && (Generator.Wis < 9));

    Generator.CheckFighter();
    Generator.CheckPaladin();
    Generator.CheckRanger();
    Generator.CheckMage();
    Generator.CheckCleric();
    Generator.CheckDruid();
    Generator.CheckThief();
    Generator.CheckBard();

    do {

        std::cout << "Available Classes:" << std::endl;

        if (Generator.IsFighterAvailable) {
            std::cout << "Fighter" << std::endl;
        }

        if (Generator.IsPaladinAvailable) {
            std::cout << "Paladin" << std::endl;
        }

        if (Generator.IsRangerAvailable) {
            std::cout << "Ranger" << std::endl;
        }

        if (Generator.IsMageAvailable) {
            std::cout << "Mage" << std::endl;
        }

        if (Generator.IsClericAvailable) {
            std::cout << "Cleric" << std::endl;
        }

        if (Generator.IsDruidAvailable) {
            std::cout << "Druid" << std::endl;
        }

        if (Generator.IsThiefAvailable) {
            std::cout << "Thief" << std::endl;
        }

        if (Generator.IsBardAvailable) {
            std::cout << "Bard" << std::endl;
        }

        std::cout << "Choose from available Classes" << std::endl;


            std::cin >> Generator.Input;

        if (Generator.IsFighterAvailable && Generator.Input == "Fighter") {
            Generator.IsInputValid = true;
        }

        else if (Generator.IsRangerAvailable && Generator.Input == "Ranger") {
            Generator.IsInputValid = true;
        }

        else if (Generator.IsPaladinAvailable && Generator.Input == "Paladin") {
            Generator.IsInputValid = true;
        }

        else if (Generator.IsMageAvailable && Generator.Input == "Mage") {
            Generator.IsInputValid = true;
        }

        else if (Generator.IsClericAvailable && Generator.Input == "Cleric") {
            Generator.IsInputValid = true;
        }

        else if (Generator.IsDruidAvailable && Generator.Input == "Druid") {
            Generator.IsInputValid = true;
        }

        else if (Generator.IsThiefAvailable && Generator.Input == "Thief") {
            Generator.IsInputValid = true;
        }

        else if (Generator.IsBardAvailable && Generator.Input == "Bard") {
            Generator.IsInputValid = true;
        }

    } while (Generator.IsInputValid == false);


    return 0;
};

