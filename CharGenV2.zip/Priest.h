#ifndef PRIEST_H
#define PRIEST_H
#include "Character.h"
#pragma once

class Priest : public Character { 

	Priest(int Str_in, int Dex_in, int Con_in, int Int_in, int Wis_in, int Cha_in, std::string CharName_in, std::string ClassName_in) :
		Character(Str_in, Dex_in, Con_in, Int_in, Wis_in, Cha_in, CharName_in, ClassName_in) {

		HitDie = 8;

		HP = 8 + HPAdj;

	};

	void SetSaves();;

	void WisdomAdj();;

	void StrAdjustment();

	void ConAdjustment();

	void IntAdjustment();;

	void LevelUp();;
};


#endif