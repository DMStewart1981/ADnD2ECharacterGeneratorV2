#ifndef ROGUE_H
#define ROGUE_H
#include "Character.h"
#pragma once

class Rogue : public Character {

	Rogue(int Str_in, int Dex_in, int Con_in, int Int_in, int Wis_in, int Cha_in, std::string CharName_in, std::string ClassName_in) :
		Character(Str_in, Dex_in, Con_in, Int_in, Wis_in, Cha_in, CharName_in, ClassName_in) {

		HitDie = 6;

		HP = 6 + HPAdj;

	};

	void SetSaves();

	void StrAdjustment();

	void ConAdjustment();

	void IntAdjustment();;

	void WisAdjustment();

	void LevelUp();

};

#endif